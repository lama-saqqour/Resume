        <div class="my-auto">
          <h2 class="mb-5">Experience</h2>
		  
		  <div class="resume-item d-flex flex-column flex-md-row mb-5">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">Technical Writer</h3>
              <div class="subheading mb-3">amoCRM / Kommo</div>
              <p>Writing best pactice for integrations by performing reverse engineering for existing integrations. Guiding developers from ouside Kommo to build new integrations by using Kommo API.</p>
            </div>
            <div class="resume-date text-md-right">
              <span class="text-primary">June 2022 - June 2023</span>
            </div>
          </div>

          <div class="resume-item d-flex flex-column flex-md-row mb-5">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">Senior Web Developer</h3>
              <div class="subheading mb-3">Technowave</div>
              <p>Woring on the "E-government website" for the Syrian governemt. Bring to the table win-win survival strategies before I left to Russia by training a group of my colleagues to conintue my work in the new versions of the project. </p>
            </div>
            <div class="resume-date text-md-right">
              <span class="text-primary">March 2020 - June 2021</span>
            </div>
          </div>

          <div class="resume-item d-flex flex-column flex-md-row mb-5">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">Web Developer</h3>
              <div class="subheading mb-3">Intelitec Solutions</div>
              <p>Develop the company website and its sisters’ companies’ websites (http://technolines.net/, http://technowave.co/).</p>
            </div>
            <div class="resume-date text-md-right">
              <span class="text-primary">May 2017 - March 2020</span>
            </div>
          </div>
		  
		  <div class="resume-item d-flex flex-column flex-md-row mb-5">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">IT Instructor</h3>
              <div class="subheading mb-3">NewHorizons</div>
              <p>Linux trainer. Red Hat Linux Essentials & Administration.</p>
            </div>
            <div class="resume-date text-md-right">
              <span class="text-primary">August 2015 - April 2017</span>
            </div>
          </div>

          <div class="resume-item d-flex flex-column flex-md-row">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">ASSISTANT PROFESSOR AND ENGINEER</h3>
              <div class="subheading mb-3">HIAST</div>
              <p>Teaching Programming, Database, Linux, Algorithms and data structure and Discrete math.</p>
			  <p>Work on Institute’s development projects for other governmental institutions.</p>
			</div>
            <div class="resume-date text-md-right">
              <span class="text-primary">January 2013 - July 2021</span>
            </div>
          </div>

        </div>
  