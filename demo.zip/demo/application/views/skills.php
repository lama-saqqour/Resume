
          <div class="subheading mb-3">Programming Languages</div>
          <ul class="list-inline">
			<li class="list-inline-item">PHP
            </li>
			<li class="list-inline-item">PHP MVC
            </li>
			<li class="list-inline-item">SQL
            </li>
            <li class="list-inline-item">HTML
            </li>
            <li class="list-inline-item">CSS3
            </li>
            <li class="list-inline-item">javascript
            </li>
            <li class="list-inline-item">API
            </li>
            <li class="list-inline-item">C++
            </li>
            <li class="list-inline-item">Python
            </li>
          </ul>
		  
          <div class="subheading mb-3">Workflow & Versioning control</div>
          <ul class="fa-ul mb-0">
            <li>Jira</li>
			<li>Agile Development &amp; Scrum</li>
            <li>Git</li>
          </ul>

		  <div class="subheading mb-3">CMS</div>
          <ul class="fa-ul mb-0">
            <li class="list-inline-item">Wordpress
            </li>
            <li class="list-inline-item">Drupal
            </li>
          </ul>
		  