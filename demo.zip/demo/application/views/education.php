<div class="resume-item d-flex flex-column flex-md-row mb-5">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">BMTSU-MOSCOW-RUSSIA</h3>
              <div class="subheading mb-3">Master degree</div>
              <div>Computer systems</div>
              <p>Score: 5</p>
            </div>
            <div class="resume-date text-md-right">
              <span class="text-primary">September 2021 - June 2023</span>
            </div>
          </div>

          <div class="resume-item d-flex flex-column flex-md-row">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">Syrian Virtual University</h3>
              <div class="subheading mb-3">Master degree</div>
              <div>Web science</div>
            </div>
            <div class="resume-date text-md-right">
              <span class="text-primary">August 2018 - April 2021</span>
            </div>
          </div>
		  
		  <div class="resume-item d-flex flex-column flex-md-row">
            <div class="resume-content mr-auto">
              <h3 class="mb-0">HIAST</h3>
              <div class="subheading mb-3">Bachelor degree</div>
              <div>Information systems engineeering</div>
            </div>
            <div class="resume-date text-md-right">
              <span class="text-primary">September 2005 - October 2012</span>
            </div>
          </div>