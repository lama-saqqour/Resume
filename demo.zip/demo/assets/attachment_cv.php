<?php
 
 error_reporting(E_ALL);
 ini_set('display_errors', 1);
 
if(isset($_FILES) && (bool) $_FILES) {
  
	$allowedExtensions = array("pdf","doc","docx");
	
	$files = array();
	foreach($_FILES as $name=>$file) {
		$file_name = $file['name']; 
		$temp_name = $file['tmp_name'];
		$file_type = $file['type'];
		$path_parts = pathinfo($file_name);
		$ext = $path_parts['extension'];
		if(!in_array($ext,$allowedExtensions)) {
			die("File $file_name has the extensions $ext which is not allowed");
		}
		array_push($files,$file);
	}
	$json_resp = array();
	 $json_resp['format']="bad";
	if(count($files)>0)
	{
	// email fields: to, from, subject, and so on
	
	$to = "info@techno-smart.org";//hr@technowave.co
	$from = $_POST['userEmail'];
	$sender = $_POST['userEmail'];
	$subject ="CV"; 
	$message = "this is my CV";
	$headers = "From: $from";
	
	// boundary 
	$semi_rand = md5(time()); 
	$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
	 
	// headers for attachment 
	$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
	 
	// multipart boundary 
	$message = "This is a multi-part message in MIME format.\n\n" . "--{$mime_boundary}\n" . "Content-Type: text/plain; charset=\"iso-8859-1\"\n" . "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 
	$message .= "--{$mime_boundary}\n";
	 
	// preparing attachments
	for($x=0;$x<count($files);$x++){
		$file = fopen($files[$x]['tmp_name'],"rb");
		$data = fread($file,filesize($files[$x]['tmp_name']));
		fclose($file);
		$data = chunk_split(base64_encode($data));
		$name = $files[$x]['name'];
		$message .= "Content-Type: {\"application/octet-stream\"};\n" . " name=\"$name\"\n" . 
		"Content-Disposition: attachment;\n" . " filename=\"$name\"\n" . 
		"Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
		$message .= "--{$mime_boundary}\n";
	}
	// send
	 unset($_POST['userEmail']);
	  unset($_POST['cvfile']);
	$ok = mail($to, $subject, $message, $headers); 

	if ($ok) { 
		$json_resp['msg']="Your CV uploaded successfully....";
		$json_resp['type']="success";
		 $json_resp['format']="yes";
	} else { 
		$json_resp['msg']="Error while uploading CV...please retry again";
		$json_resp['type']="error";
		 $json_resp['format']="yes";
	} 
	}
	else
	  $json_resp['format']="bad";
	echo json_encode($json_resp);
}	
 
?>