<?php
 
 error_reporting(E_ALL);
 ini_set('display_errors', 1);
 

  
	
	$data = array();
	 $data['format']="bad";
	
	// email fields: to, from, subject, and so on
	
	$to = "info@techno-smart.org";
	$userEmail = $_POST['userEmail'];
	$userName = $_POST['userName'];
	$userCompany =$_POST['userCompany'];
	$userMessage = $_POST['userMessage'];
	$subject="Message from ".$userName;
	
	// boundary 
	$semi_rand = md5(time()); 
	$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
	 
	// headers for attachment 
	$headers= 'From: '.$userEmail."\r\n";
	 
	 $message='Name: '.$userName."\r\n\r\n";
	 $message.='Company: '.$userCompany."\r\n\r\n";
	 $message.='Message: '.$userMessage;
	// preparing attachments
	
	
	// send
	
	
	$ok = mail($to, $subject, $message, $headers); 
	 unset($_POST['userEmail']);
	unset($_POST['userName']);
	unset($_POST['userCompany']);
	 unset($_POST['userMessage']);
	if ($ok) { 
		$data['type']="success";
		$data['text']="Your message sent successfully....";

	} else { 
		$data['type']="error";
		$data['text']="Your message was not sent, please check your info....";
	} 

	//else
	//  $data['format']="bad";
	echo json_encode($data);

 
?>